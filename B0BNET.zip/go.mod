module b0bnet

go 1.18

require (
	github.com/go-sql-driver/mysql v1.7.1
	github.com/mattn/go-shellwords v1.0.12
)
