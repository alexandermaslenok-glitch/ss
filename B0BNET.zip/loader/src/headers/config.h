#pragma once

#define HTTP_SERVER "98.91.254.110"
#define HTTP_PORT 80

#define TFTP_SERVER "98.91.254.110"
